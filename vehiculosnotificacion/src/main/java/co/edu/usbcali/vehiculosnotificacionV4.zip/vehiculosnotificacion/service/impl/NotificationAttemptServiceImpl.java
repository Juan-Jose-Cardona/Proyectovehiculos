package co.edu.usbcali.vehiculosnotificacion.service.impl;


import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateNotificationAttemptRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateNotificationAttemptResponse;
import co.edu.usbcali.vehiculosnotificacion.mapper.NotificationAttemptMapper;
import co.edu.usbcali.vehiculosnotificacion.model.Notification;
import co.edu.usbcali.vehiculosnotificacion.model.NotificationAttempt;
import co.edu.usbcali.vehiculosnotificacion.repository.NotificationAttemptRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.NotificationRepository;
import co.edu.usbcali.vehiculosnotificacion.service.NotificationAttemptService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class NotificationAttemptServiceImpl implements NotificationAttemptService {

    private final NotificationAttemptRepository notificationAttemptRepository;
    private final NotificationRepository notificationRepository;

    @Override
    public CreateNotificationAttemptResponse createNotificationAttempt(
            CreateNotificationAttemptRequest createNotificationAttemptRequest
    ) throws Exception {

        if (createNotificationAttemptRequest == null) {
            throw new Exception("El objeto CreateNotificationAttemptRequest no puede ser nulo");
        }

        if (createNotificationAttemptRequest.getNotificationId() == null
                || createNotificationAttemptRequest.getNotificationId() <= 0) {
            throw new Exception("El notificationId es requerido");
        }

        if (createNotificationAttemptRequest.getAttemptNo() == null
                || createNotificationAttemptRequest.getAttemptNo() <= 0) {
            throw new Exception("El numero de intento es requerido");
        }

        if (createNotificationAttemptRequest.getProvider() != null
                && createNotificationAttemptRequest.getProvider().length() > 100) {
            throw new Exception("El provider soporta hasta 100 caracteres");
        }

        if (createNotificationAttemptRequest.getSuccess() == null) {
            throw new Exception("El estado success es requerido");
        }

        Notification notification = notificationRepository.findById(createNotificationAttemptRequest.getNotificationId())
                .orElseThrow(() -> new Exception(
                        "No se encontro la notification con id " + createNotificationAttemptRequest.getNotificationId()
                ));

        NotificationAttempt notificationAttempt = NotificationAttemptMapper.createNotificationAttemptRequestToEntity(
                createNotificationAttemptRequest,
                notification
        );

        notificationAttempt = notificationAttemptRepository.save(notificationAttempt);

        return NotificationAttemptMapper.entityToCreateNotificationAttemptResponse(notificationAttempt);
    }

}
