package co.edu.usbcali.vehiculosnotificacion.service;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateNotificationAttemptRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateNotificationAttemptResponse;

public interface NotificationAttemptService {

    CreateNotificationAttemptResponse createNotificationAttempt(CreateNotificationAttemptRequest createNotificationAttemptRequest) throws Exception;

}
