package co.edu.usbcali.vehiculosnotificacion.service;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateAuditLogRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateAuditLogResponse;

public interface AuditLogService {

    CreateAuditLogResponse createAuditLog(CreateAuditLogRequest createAuditLogRequest) throws Exception;

}
