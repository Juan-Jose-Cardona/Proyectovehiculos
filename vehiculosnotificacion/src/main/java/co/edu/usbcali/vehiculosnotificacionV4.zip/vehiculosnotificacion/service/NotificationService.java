package co.edu.usbcali.vehiculosnotificacion.service;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateNotificationRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateNotificationResponse;

public interface NotificationService {

    CreateNotificationResponse createNotification(CreateNotificationRequest createNotificationRequest) throws Exception;

}
