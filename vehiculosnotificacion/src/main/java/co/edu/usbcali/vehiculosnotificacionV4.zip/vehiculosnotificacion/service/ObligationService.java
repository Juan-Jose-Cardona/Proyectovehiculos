package co.edu.usbcali.vehiculosnotificacion.service;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateObligationRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateObligationResponse;


public interface ObligationService {

    CreateObligationResponse createObligation(CreateObligationRequest createObligationRequest) throws Exception;

}
