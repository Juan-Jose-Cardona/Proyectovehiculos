package co.edu.usbcali.vehiculosnotificacion.service.impl;


import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateNotificationRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateNotificationResponse;
import co.edu.usbcali.vehiculosnotificacion.mapper.NotificationMapper;
import co.edu.usbcali.vehiculosnotificacion.model.Notification;
import co.edu.usbcali.vehiculosnotificacion.model.Obligation;
import co.edu.usbcali.vehiculosnotificacion.model.User;
import co.edu.usbcali.vehiculosnotificacion.model.Vehicle;
import co.edu.usbcali.vehiculosnotificacion.repository.NotificationRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.ObligationRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.UserRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.VehicleRepository;
import co.edu.usbcali.vehiculosnotificacion.service.NotificationService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final VehicleRepository vehicleRepository;
    private final ObligationRepository obligationRepository;

    @Override
    public CreateNotificationResponse createNotification(CreateNotificationRequest createNotificationRequest) throws Exception {

        if (createNotificationRequest == null) {
            throw new Exception("El objeto CreateNotificationRequest no puede ser nulo");
        }

        if (createNotificationRequest.getUserId() == null || createNotificationRequest.getUserId() <= 0) {
            throw new Exception("El userId es requerido");
        }

        if (createNotificationRequest.getVehicleId() == null || createNotificationRequest.getVehicleId() <= 0) {
            throw new Exception("El vehicleId es requerido");
        }

        if (createNotificationRequest.getObligationId() == null || createNotificationRequest.getObligationId() <= 0) {
            throw new Exception("El obligationId es requerido");
        }

        if (createNotificationRequest.getChannel() == null) {
            throw new Exception("El canal es requerido");
        }

        if (createNotificationRequest.getDueDate() == null) {
            throw new Exception("La fecha de vencimiento es requerida");
        }

        if (createNotificationRequest.getScheduledFor() == null) {
            throw new Exception("La fecha programada es requerida");
        }

        User user = userRepository.findById(createNotificationRequest.getUserId())
                .orElseThrow(() -> new Exception(
                        "No se encontro el user con id " + createNotificationRequest.getUserId()
                ));

        Vehicle vehicle = vehicleRepository.findById(createNotificationRequest.getVehicleId())
                .orElseThrow(() -> new Exception(
                        "No se encontro el vehicle con id " + createNotificationRequest.getVehicleId()
                ));

        Obligation obligation = obligationRepository.findById(createNotificationRequest.getObligationId())
                .orElseThrow(() -> new Exception(
                        "No se encontro la obligation con id " + createNotificationRequest.getObligationId()
                ));

        Notification notification = NotificationMapper.createNotificationRequestToEntity(
                createNotificationRequest,
                user,
                vehicle,
                obligation
        );

        notification = notificationRepository.save(notification);

        return NotificationMapper.entityToCreateNotificationResponse(notification);
    }

}
