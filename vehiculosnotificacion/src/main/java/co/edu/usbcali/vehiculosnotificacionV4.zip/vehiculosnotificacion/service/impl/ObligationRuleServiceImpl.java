package co.edu.usbcali.vehiculosnotificacion.service.impl;


import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateObligationRuleRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateObligationRuleResponse;
import co.edu.usbcali.vehiculosnotificacion.mapper.ObligationRuleMapper;
import co.edu.usbcali.vehiculosnotificacion.model.Obligation;
import co.edu.usbcali.vehiculosnotificacion.model.ObligationRule;
import co.edu.usbcali.vehiculosnotificacion.repository.ObligationRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.ObligationRuleRepository;
import co.edu.usbcali.vehiculosnotificacion.service.ObligationRuleService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ObligationRuleServiceImpl implements ObligationRuleService {

    private final ObligationRuleRepository obligationRuleRepository;
    private final ObligationRepository obligationRepository;

    @Override
    public CreateObligationRuleResponse createObligationRule(CreateObligationRuleRequest createObligationRuleRequest) throws Exception {

        if (createObligationRuleRequest == null) {
            throw new Exception("El objeto CreateObligationRuleRequest no puede ser nulo");
        }

        if (createObligationRuleRequest.getObligationId() == null
                || createObligationRuleRequest.getObligationId() <= 0) {
            throw new Exception("El obligationId es requerido");
        }

        Obligation obligation = obligationRepository.findById(createObligationRuleRequest.getObligationId())
                .orElseThrow(() -> new Exception(
                        "No se encontro la obligation con id " + createObligationRuleRequest.getObligationId()
                ));

        ObligationRule obligationRule = ObligationRuleMapper.createObligationRuleRequestToEntity(
                createObligationRuleRequest,
                obligation
        );

        obligationRule = obligationRuleRepository.save(obligationRule);

        return ObligationRuleMapper.entityToCreateObligationRuleResponse(obligationRule);
    }

}
