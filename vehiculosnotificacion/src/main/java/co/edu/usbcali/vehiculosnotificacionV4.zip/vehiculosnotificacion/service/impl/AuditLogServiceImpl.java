package co.edu.usbcali.vehiculosnotificacion.service.impl;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateAuditLogRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateAuditLogResponse;
import co.edu.usbcali.vehiculosnotificacion.mapper.AuditLogMapper;
import co.edu.usbcali.vehiculosnotificacion.model.AuditLog;
import co.edu.usbcali.vehiculosnotificacion.model.User;
import co.edu.usbcali.vehiculosnotificacion.repository.AuditLogRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.UserRepository;
import co.edu.usbcali.vehiculosnotificacion.service.AuditLogService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    @Override
    public CreateAuditLogResponse createAuditLog(CreateAuditLogRequest createAuditLogRequest) throws Exception {

        if (createAuditLogRequest == null) {
            throw new Exception("El objeto CreateAuditLogRequest no puede ser nulo");
        }

        if (createAuditLogRequest.getUserId() == null || createAuditLogRequest.getUserId() <= 0) {
            throw new Exception("El userId es requerido");
        }

        if (createAuditLogRequest.getEntityType() == null || createAuditLogRequest.getEntityType().isBlank()) {
            throw new Exception("El tipo de entidad es requerido");
        }

        if (createAuditLogRequest.getEntityType().length() > 100) {
            throw new Exception("El tipo de entidad soporta hasta 100 caracteres");
        }

        if (createAuditLogRequest.getAction() == null) {
            throw new Exception("La accion es requerida");
        }

        User user = userRepository.findById(createAuditLogRequest.getUserId())
                .orElseThrow(() -> new Exception(
                        "No se encontro el user con id " + createAuditLogRequest.getUserId()
                ));

        AuditLog auditLog = AuditLogMapper.createAuditLogRequestToEntity(createAuditLogRequest, user);

        auditLog = auditLogRepository.save(auditLog);

        return AuditLogMapper.entityToCreateAuditLogResponse(auditLog);
    }

}
