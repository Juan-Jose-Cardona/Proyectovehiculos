package co.edu.usbcali.vehiculosnotificacion.service;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateObligationRuleRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateObligationRuleResponse;

public interface ObligationRuleService {

    CreateObligationRuleResponse createObligationRule(CreateObligationRuleRequest createObligationRuleRequest) throws Exception;


}
