package co.edu.usbcali.vehiculosnotificacion.service.impl;


import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateObligationRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateObligationResponse;
import co.edu.usbcali.vehiculosnotificacion.mapper.ObligationMapper;
import co.edu.usbcali.vehiculosnotificacion.model.Obligation;
import co.edu.usbcali.vehiculosnotificacion.model.Vehicle;
import co.edu.usbcali.vehiculosnotificacion.repository.ObligationRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.VehicleRepository;
import co.edu.usbcali.vehiculosnotificacion.service.ObligationService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ObligationServiceImpl implements ObligationService {

    private final ObligationRepository obligationRepository;
    private final VehicleRepository vehicleRepository;

    @Override
    public CreateObligationResponse createObligation(CreateObligationRequest createObligationRequest) throws Exception {

        if (createObligationRequest == null) {
            throw new Exception("El objeto CreateObligationRequest no puede ser nulo");
        }

        if (createObligationRequest.getVehicleId() == null || createObligationRequest.getVehicleId() <= 0) {
            throw new Exception("El vehicleId es requerido");
        }

        if (createObligationRequest.getType() == null) {
            throw new Exception("El tipo de obligacion es requerido");
        }

        if (createObligationRequest.getDueDate() == null) {
            throw new Exception("La fecha de vencimiento es requerida");
        }

        Vehicle vehicle = vehicleRepository.findById(createObligationRequest.getVehicleId())
                .orElseThrow(() -> new Exception(
                        "No se encontro el vehicle con id " + createObligationRequest.getVehicleId()
                ));

        Obligation obligation = ObligationMapper.createObligationRequestToEntity(
                createObligationRequest,
                vehicle
        );

        obligation = obligationRepository.save(obligation);

        return ObligationMapper.entityToCreateObligationResponse(obligation);
    }

}
