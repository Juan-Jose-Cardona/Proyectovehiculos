package co.edu.usbcali.vehiculosnotificacion.controller;

public class ObligationRuleNotifyDayController {
}
