package co.edu.usbcali.vehiculosnotificacion.dto.request;

public class UpdateObligationRuleChannelRequest {
}
