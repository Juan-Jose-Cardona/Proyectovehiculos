package co.edu.usbcali.vehiculosnotificacion.mapper;

public class ObligationRuleNotifyDayMapper {
}
