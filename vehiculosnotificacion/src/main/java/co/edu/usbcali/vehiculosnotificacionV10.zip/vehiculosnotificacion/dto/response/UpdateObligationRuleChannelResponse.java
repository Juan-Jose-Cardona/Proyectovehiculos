package co.edu.usbcali.vehiculosnotificacion.dto.response;

public class UpdateObligationRuleChannelResponse {
}
