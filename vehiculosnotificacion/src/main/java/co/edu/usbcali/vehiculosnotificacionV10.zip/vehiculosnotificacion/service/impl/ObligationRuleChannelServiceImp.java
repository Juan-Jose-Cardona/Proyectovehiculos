package co.edu.usbcali.vehiculosnotificacion.service.impl;

public class ObligationRuleChannelServiceImp {
}
