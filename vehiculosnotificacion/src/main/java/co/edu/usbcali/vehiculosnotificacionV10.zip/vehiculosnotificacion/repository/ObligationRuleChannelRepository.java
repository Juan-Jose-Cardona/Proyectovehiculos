package co.edu.usbcali.vehiculosnotificacion.repository;

public interface ObligationRuleChannelRepository {
}
