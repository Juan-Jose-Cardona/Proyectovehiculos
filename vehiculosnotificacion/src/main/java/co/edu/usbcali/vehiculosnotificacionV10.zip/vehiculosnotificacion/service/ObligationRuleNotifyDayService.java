package co.edu.usbcali.vehiculosnotificacion.service;

public interface ObligationRuleNotifyDayService {
}
