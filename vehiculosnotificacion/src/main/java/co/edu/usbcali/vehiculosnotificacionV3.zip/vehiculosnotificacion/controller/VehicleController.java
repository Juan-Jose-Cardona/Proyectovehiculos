package co.edu.usbcali.vehiculosnotificacion.controller;


import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateVehicleRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateVehicleResponse;
import co.edu.usbcali.vehiculosnotificacion.repository.VehicleRepository;
import co.edu.usbcali.vehiculosnotificacion.service.VehicleService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/vehicles")
public class VehicleController {


    private final VehicleService vehicleService;

    @GetMapping("/ping")
    public String ping() {
        return "pong";
    }

    @PostMapping("/create")
    public ResponseEntity<CreateVehicleResponse> createVehicle(
            @RequestBody CreateVehicleRequest createVehicleRequest
    ) throws Exception {

        CreateVehicleResponse vehicleCreated = vehicleService.createVehicle(createVehicleRequest);

        return new ResponseEntity<>(
                vehicleCreated,
                HttpStatus.CREATED
        );
    }

}
