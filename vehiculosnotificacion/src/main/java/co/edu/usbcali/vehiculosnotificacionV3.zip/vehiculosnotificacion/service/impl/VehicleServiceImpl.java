package co.edu.usbcali.vehiculosnotificacion.service.impl;

import co.edu.usbcali.vehiculosnotificacion.dto.request.CreateVehicleRequest;
import co.edu.usbcali.vehiculosnotificacion.dto.response.CreateVehicleResponse;
import co.edu.usbcali.vehiculosnotificacion.mapper.VehicleMapper;
import co.edu.usbcali.vehiculosnotificacion.model.User;
import co.edu.usbcali.vehiculosnotificacion.model.Vehicle;
import co.edu.usbcali.vehiculosnotificacion.repository.UserRepository;
import co.edu.usbcali.vehiculosnotificacion.repository.VehicleRepository;
import co.edu.usbcali.vehiculosnotificacion.service.VehicleService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

@Service
@AllArgsConstructor
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository vehicleRepository;
    private final UserRepository userRepository;

    @Override
    public CreateVehicleResponse createVehicle(CreateVehicleRequest createVehicleRequest) throws Exception {

        try {
            if (Objects.isNull(createVehicleRequest)) {
                throw new Exception("El objeto CreateVehicleRequest no puede ser nulo");
            }

            if (Objects.isNull(createVehicleRequest.getUserId()) || createVehicleRequest.getUserId() <= 0) {
                throw new Exception("El userId es requerido y debe ser mayor a 0");
            }

            if (Objects.isNull(createVehicleRequest.getPlate()) || createVehicleRequest.getPlate().isBlank()) {
                throw new Exception("La placa es requerida");
            }

            if (createVehicleRequest.getPlate().length() > 20) {
                throw new Exception("La placa soporta hasta 20 caracteres");
            }

            if (Objects.isNull(createVehicleRequest.getVehicleType()) || createVehicleRequest.getVehicleType().isBlank()) {
                throw new Exception("El tipo de vehiculo es requerido");
            }

            User user = userRepository.findById(createVehicleRequest.getUserId())
                    .orElseThrow(() -> new Exception(
                            "No se ha encontrado el user con el id " + createVehicleRequest.getUserId()
                    ));

            boolean vehicleAlreadyExists = vehicleRepository.existsByUserIdAndPlate(
                    createVehicleRequest.getUserId(),
                    createVehicleRequest.getPlate()
            );

            if (vehicleAlreadyExists) {
                throw new Exception("Ya existe un vehiculo con esa placa para este usuario");
            }

            Vehicle vehicle = Vehicle.builder()
                    .user(user)
                    .plate(createVehicleRequest.getPlate())
                    .brand(createVehicleRequest.getBrand())
                    .lineModel(createVehicleRequest.getLineModel())
                    .modelYear(createVehicleRequest.getModelYear())
                    .vehicleType(createVehicleRequest.getVehicleType())
                    .notes(createVehicleRequest.getNotes())
                    .createdAt(createVehicleRequest.getCreatedAt())
                    .updatedAt(createVehicleRequest.getUpdatedAt())
                    .build();

            vehicle = vehicleRepository.save(vehicle);

            return VehicleMapper.entityToCreateVehicleResponse(vehicle);

        } catch (Exception e) {
            throw e;
        }
    }
}
