package co.edu.usbcali.vehiculosnotificacion.dto.request;


import co.edu.usbcali.vehiculosnotificacion.model.enums.ChannelType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

//valids
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;



@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CreateObligationRuleChannelRequest {

    // Atributos de la clase

    //atributos que se van a pedir
    @NotNull(message = "El obligationRuleId es requerido")
    @Positive(message = "El obligationRuleId debe ser mayor a 0")
    private Integer obligationRuleId;

    //valida dia requerido
    @NotNull(message = "El notifyDay es requerido")
    @Min(value = 0, message = "El notifyDay debe ser mayor o igual a 0")
    private Integer notifyDay;

}
